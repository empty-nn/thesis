# Travel RAG FastAPI

This folder converts the uploaded stage-by-stage Travel RAG notebook into
a reusable FastAPI layer.

It is designed to be copied into the ROOT of your existing Python project,
where these modules already exist:

```text
db/session.py
db/full_model.py
config/vocab.py
data_building/extract_metadata/extractor.py
```

The API does not duplicate those files.

---

## 1. Resulting project structure

```text
your-backend/
├── api/
│   ├── main.py
│   ├── core/
│   │   └── model_registry.py
│   ├── routers/
│   │   ├── chat.py
│   │   ├── health.py
│   │   └── retrieval_debug.py
│   ├── schemas/
│   │   ├── chat.py
│   │   ├── pipeline.py
│   │   └── retrieval_debug.py
│   └── services/
│       ├── answer_pipeline.py
│       ├── debug_pipeline.py
│       ├── memory.py
│       ├── pipeline_runner.py
│       ├── query_processing.py
│       └── retrieval.py
│
├── config/
├── data_building/
├── db/
└── ...
```

---

## 2. Install

Use your existing virtual environment.

```bash
pip install -r requirements-api.txt
```

If most of these packages are already in your requirements file, just add:

```text
fastapi
uvicorn[standard]
```

and keep your existing compatible versions.

---

## 3. Start FastAPI

From the project root:

```bash
uvicorn api.main:app --reload --host 127.0.0.1 --port 8000
```

Open Swagger:

```text
http://127.0.0.1:8000/docs
```

Health:

```text
GET http://127.0.0.1:8000/api/health
```

---

## 4. Angular connection

In the Angular project:

```ts
export const environment = {
  production: false,
  useMockApi: false,
  apiBaseUrl: 'http://localhost:8000/api',
};
```

Also change the retrieval chunk ID:

```ts
export interface RetrievalChunk {
  id: string;
  // ...
}
```

Your database uses UUID chunk IDs.

---

# API endpoints

## POST `/api/retrieval/debug`

Request:

```json
{
  "query": "best cultural attractions in Hue"
}
```

Optional full request:

```json
{
  "query": "Plan family-friendly activities in Da Nang for 3 days",
  "conversation_history": [],
  "user_id": null,
  "vector_limit": 30,
  "bm25_limit": 30,
  "fusion_top_k": 20,
  "rerank_top_k": 8,
  "target_lat": null,
  "target_lon": null
}
```

Response stages:

```text
Vector
  ↓
BM25
  ↓
Hybrid / RRF + boosts
  ↓
CrossEncoder rerank
  ↓
Final evidence
```

The returned JSON matches the Angular Retrieval Debug page.

Each chunk contains:

```text
id
rank
score
vectorScore
bm25Score
rerankScore
title
city
placeName
topic
sourceName
sourceUrl
content
metadata
```

The response also includes diagnostics for:

```text
original query
rewritten query
parsed query
hard filters
retrieval confidence
query rewrite latency
query parser latency
memory latency
filter latency
```

---

## POST `/api/chat`

Request used by your Angular chat service:

```json
{
  "message": "Plan a 3 day trip to Da Nang"
}
```

It also accepts optional history:

```json
{
  "message": "What about something near there for kids?",
  "conversation_history": [
    {
      "role": "user",
      "content": "What should I do in Hoi An?"
    },
    {
      "role": "assistant",
      "content": "..."
    }
  ],
  "user_id": "test-user"
}
```

Response:

```json
{
  "answer": "Markdown answer...",
  "sources": [
    {
      "id": "...",
      "title": "...",
      "url": "..."
    }
  ]
}
```

---

# What was preserved from the notebook

The API preserves:

1. DeepSeek query rewriting with safe fallback.
2. DeepSeek semantic query parsing.
3. Dynamic known-city lookup from `rag_chunks`.
4. Controlled vocabulary validation.
5. User-memory placeholder.
6. Metadata hard filters.
7. `all-MiniLM-L6-v2` vector retrieval.
8. BM25 retrieval.
9. BM25 text enrichment:
   - place name
   - AI summary
   - chunk text
10. Reciprocal Rank Fusion.
11. Metadata soft boost.
12. Geographic boost.
13. Freshness boost.
14. Top-20 candidate pruning.
15. `cross-encoder/ms-marco-MiniLM-L-6-v2` reranking.
16. Retrieval confidence.
17. Evidence construction.
18. Mock itinerary drafting.
19. Frontend response.

---

# Small API improvements made intentionally

## Models load once

The notebook creates:

```python
SentenceTransformer(...)
CrossEncoder(...)
```

at module execution time.

The API loads them once in FastAPI lifespan instead.

This avoids recreating the models per request.

## Actual debug scores

The notebook displays retrieval rank but does not preserve an explicit BM25
score.

The API keeps the notebook's `BM25Retriever` and reads its underlying BM25
vectorizer scores so the frontend can inspect the real stage score.

Vector `<=>` distance is also converted to:

```text
cosine similarity = 1 - cosine distance
```

for easier interpretation.

## Vector hard filters

The notebook's BM25 path applies:

```text
country
city
province
place_types
```

but its vector SQL only applies city/province.

The API applies the same hard-filter set to vector retrieval, so hybrid search
does not retrieve candidates that BM25 would reject.

## Source URL

Vector SQL joins the `documents` table so:

```text
documents.source_location
```

can be returned to Angular as `sourceUrl`.

---

# Important: generation is still mock

The notebook's retrieval pipeline is real, but the final itinerary function is:

```text
draft_itinerary_mock(...)
```

This API intentionally keeps that behavior instead of silently inventing a new
LLM generation pipeline.

So at this stage:

```text
retrieval-debug = real
chat retrieval = real
final itinerary writing = mock
```

The next clean step is to replace only:

```text
api/services/answer_pipeline.py
    draft_itinerary_mock()
```

with an evidence-grounded DeepSeek answer generator.

Everything before that can remain unchanged.

---

# Recommended test order

First:

```bash
uvicorn api.main:app --reload
```

Then Swagger:

```text
http://127.0.0.1:8000/docs
```

Run:

```text
GET /api/health
```

Then:

```text
POST /api/retrieval/debug
```

with:

```json
{
  "query": "best cultural attractions in Hue"
}
```

Only after retrieval debug returns real database chunks, switch Angular:

```ts
useMockApi: false
```

Then test `/retrieval-debug` in the browser.
